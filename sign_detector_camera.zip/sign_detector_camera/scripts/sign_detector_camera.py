#!/usr/bin/env python

import rospy   
import cv2
import numpy as np
import pytesseract
import os, rospkg

from sensor_msgs.msg import Image
from std_msgs.msg import String
from cv_bridge import CvBridge, CvBridgeError
from PIL import Image as im


class SignDetector:
     
     def __init__(self):

          self.bridge = CvBridge()
          self.map_state = rospy.Subscriber("/map_state", String, self.mapCallback)
          # self.image_sub = rospy.Subscriber("/camera/image_raw", Image, self.callback)
          self.image_sub = rospy.Subscriber("/usb_cam/image_raw", Image, self.callback)
          self.sign_state_pub = rospy.Publisher("/sign_state", String, queue_size=10)
          self.result_A = None
          self.result_B = None
          self.sign_A = False
          self.sign_B = False
          self.lower_w = np.array([0,0,130])
          self.upper_w = np.array([190,70,255])
          self.map = None

     def mapCallback(self, data):
          self.map = data.data

     def callback(self, data):
          try:
               cv_img = self.bridge.imgmsg_to_cv2(data, desired_encoding="rgb8")
          except CvBridgeError as e:
               print(e)

          # roi_img = self.mask_roi(img)
          img = cv2.resize(cv_img, dsize=(640, 480), interpolation=cv2.INTER_AREA)
          roi_img = img[100:380, 320:640]
          sign_msg = self.ExtractNumber(roi_img)

          # print("----",sign_msg,"----")
          # self.FindResultA(sign_msg)
          # self.FindResultB(sign_msg)
          # print(self.map)

 
          if self.map == "A_delivery" :
               if self.sign_A == False :
                    self.sign_state_pub.publish("wait A")
                    print("wait A")
                    self.FindResultA(sign_msg)
               else :
                    self.sign_state_pub.publish("read A")
                    print("read A*************"+self.result_A)
          if self.map == "B_delivery" :
               if self.sign_B == False :
                    self.sign_state_pub.publish("wait B")
                    print("wait B")
                    self.FindResultB(sign_msg)
               else :
                    self.sign_state_pub.publish("read B")
                    print("read B*************"+self.result_B)


            
     def ExtractNumber(self, img):
          cv2.imshow('img',img)
          cv2.waitKey(1)  
          
          copy_img=img.copy()

          img2=cv2.cvtColor(img,cv2.COLOR_BGR2HSV)
          # img2=cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)

          Rmask = cv2.inRange(img2, np.array([-10, 50, 50]), np.array([40, 255, 255]))
          # cv2.imshow('Rmask',Rmask)
          
          blur = cv2.GaussianBlur(Rmask,(5,5),0)
          # cv2.imshow('blur',blur)

          canny=cv2.Canny(blur,100,200)
          # cv2.imshow("canny", canny)

          # thr = cv2.adaptiveThreshold(Rmask, 255, cv2.ADAPTIVE_THRESH_MEAN_C,  cv2.THRESH_BINARY_INV, 3, 30) 
          # cv2.imshow('thr',thr)

          contours,hierarchy  = cv2.findContours(canny, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
          
          for cnt in contours:          
               # area = cv2.contourArea(cnt)
               x,y,w,h = cv2.boundingRect(cnt)
               rect_area=w*h  #area size
               aspect_ratio = float(w)/h # ratio = width/height

               # if (aspect_ratio>=0.95)and(aspect_ratio<=1.2)and(rect_area>=60**2) :  and(rect_area<=110**2)
               #      cv2.rectangle(img,(x,y),(x+w,y+h),(0,255,0),1)
               #      print(x, y, w, h, aspect_ratio, rect_area)
               #      cv2.imshow('snake',img)
                  
               # if  (aspect_ratio>=0.2)and(aspect_ratio<=1.0)and(rect_area>=100)and(rect_area<=700):  
               if (aspect_ratio>=0.95)and(aspect_ratio<=1.2)and(rect_area>=2800) :
                    cv2.rectangle(img,(x,y),(x+w,y+h),(0,255,0),1)
                    rect = cv2.minAreaRect(cnt)  #(center(x2,y2), (width2, height2), rotation)
                    box1 = cv2.boxPoints(rect)
                    box2 = np.int0(box1)
                    cv2.drawContours(img, [box2], 0, (0,0,255), 1)
                    # rot = cv2.getRotationMatrix2D((int(rect[1][0])/2, int(rect[1][1])/2), -int(rect[-1]), 1)
                    rot = cv2.getRotationMatrix2D((w/2, h/2), int(rect[-1]), 1)
                    
                    # number_plate2=tr_img[y+10: y + h-10, x+10: x + w-10]
                    
                    number_plate=copy_img[y+10: y + h-10, x+10: x + w-10]
                    cv2.imshow('snake',img)

                    tr_img = cv2.warpAffine(number_plate, rot, (w-10,h-10))
                    # cv2.imshow('rot', tr_img)
                    # cv2.imshow('number',number_plate)    
                    # cv2.waitKey(1)      
                    
                    resize_plate=cv2.resize(tr_img,None,fx=1.8,fy=1.8,interpolation=cv2.INTER_CUBIC+cv2.INTER_LINEAR) 
                    # cv2.imshow('re', resize_plate)
                    plate_gray=cv2.cvtColor(resize_plate,cv2.COLOR_BGR2GRAY)
                    # cv2.imshow('pl', plate_gray)

                 
                    # img2Norm = cv2.normalize(plate_gray, None, 0, 255, cv2.NORM_MINMAX)
                    # h,s,v = cv2.split(resize_plate)
                    # ret,th_plate = cv2.threshold(plate_gray,150,255,cv2.THRESH_BINARY)
                    # img_w = cv2.inRange(plate_gray, self.lower_w, self.upper_w)

                    img_w = cv2.threshold(plate_gray, 130 , 255,cv2.THRESH_BINARY_INV)[1]
                    cv2.imshow("img_w", img_w)
                    
                    # cv2.imshow('plate_th',th_plate)

                    # img_w = cv2.dilate(img_w,kernel,iterations=1)
                    # img_w = cv2.erode(img_w,kernel,iterations=4)
                    # img_w = cv2.dilate(img_w,kernel,iterations=2)
                    img_w = cv2.morphologyEx(img_w, cv2.MORPH_OPEN, (5,5))
                    # img_w = cv2.dilate(img_w,kernel,iterations=2)

                    img_f = im.fromarray(img_w)
                    msg = pytesseract.image_to_string(img_f, lang='eng', config='-psm 10')
                    sign_msg = msg.replace(" ","")

                    return sign_msg

     
     def FindResultA(self, sign_msg):
          A1_list = ['A1','Al','|A1','A1|','A|','A!','Ai','AI','AT','AY','A/']
          A2_list = ['A2','|A2','A2|', 'Ae', 'Ad', 'AC', 'Ac', 'A?', 'AZ', 'A2!','Wa','Az','A2\'','N2','NC','NZ','Nz']
          A3_list = ['A3','|A3','A3|','AS']  

          if sign_msg in A1_list:
               self.result_A = 'A1' 
          elif sign_msg in A2_list:
               self.result_A = 'A2'  
          elif sign_msg in A3_list:
               self.result_A = 'A3'

          if self.result_A != None:
               self.sign_A = True
               print("result_A=", self.result_A) 



     def FindResultB(self, sign_msg):
          B1_list = ['B1','Bl','|B1','B1|','B|','B!','Bi','BI','BT','BY','B/', 'Bl!']
          B2_list = ['B2','|B2','B2|','Be', 'B2\'', '52']
          B3_list = ['B3','|B3','B3|','BS']          

          if sign_msg in B1_list:
               self.result_B = 'B1'
          elif sign_msg in B2_list:
               self.result_B = 'B2' 
          elif sign_msg in B3_list:
               self.result_B = 'B3'

          if self.result_B != None and (str(self.result_B)[-1] == str(self.result_A)[-1]):
               self.sign_B = True
               print("result_B=",self.result_B)





if __name__ == '__main__':
        
     rospy.init_node('sign_detector_camera', anonymous=True)
     rate = rospy.Rate(10)
     SignDetector()

     rospy.spin() 




    
    
          

