#!/usr/bin/env python

import rospy   
import cv2
import numpy as np
import pytesseract
import os, rospkg

from sensor_msgs.msg import Image
from std_msgs.msg import String
from cv_bridge import CvBridge, CvBridgeError

GO_TO_SIGN_SEC = 6
WAIT_FOR_DELIVERY_TIME_SEC = 5


class SignDetector:
     

     def __init__(self):

          self.bridge = CvBridge()
          # self.image_sub = rospy.Subscriber("/usb_cam/image_raw", Image, self.callback)        
          # self.image_sub = rospy.Subscriber("/camera1/usb_cam1/image_raw", Image, self.callback) 
          self.image_sub = rospy.Subscriber("/camera/image_raw", Image, self.callback) 
          self.sign_state_pub = rospy.Publisher("/sign_state", String)
          self.result_A = None
          self.result_B = None
          self.fail_A = []
          self.time_A = []
          self.time_B = []
          self.sign = False
          self.count = 0
          self.lower_w = np.array([0,0,130])
          self.upper_w = np.array([190,70,255])

          # self.crop_pts = np.array([[[320,360],[320,100],[640,100],[640,360]]])



     def callback(self, data):
          try:
               cv_img = self.bridge.imgmsg_to_cv2(data, desired_encoding="rgb8")
               img = cv2.resize(cv_img, dsize=(640, 480), interpolation=cv2.INTER_AREA)
          except CvBridgeError as e:
               print(e)
          # roi_img = self.mask_roi(img)
          roi_img = img[100:380, 320:640]
          sign_msg = self.ExtractNumber(roi_img)
          self.FindResultA(sign_msg)
          self.FindResultB(sign_msg)


     # def mask_roi(self, img):

     #      h = img.shape[0]
     #      w = img.shape[1]
        
     #      if len(img.shape)==3:
     #           # num of channel = 3

     #           c = img.shape[2]
     #           mask = np.zeros((h, w, c), dtype=np.uint8)

     #           mask_value = (255, 255, 255)

     #      else:
     #           # grayscale

     #           c = img.shape[2]
     #           mask = np.zeros((h, w, c), dtype=np.uint8)

     #           mask_value = (255)

     #      cv2.fillPoly(mask, self.crop_pts, mask_value)

     #      mask = cv2.bitwise_and(mask, img)

     #      return mask
            
     def ExtractNumber(self, img):
          cv2.imshow('img',img)
          cv2.waitKey(1)  
          
          copy_img=img.copy()
          img2=cv2.cvtColor(img,cv2.COLOR_BGR2HSV)
          Rmask = cv2.inRange(img2, np.array([-10, 50, 50]), np.array([40, 255, 255]))
          # cv2.imshow('Rmask',Rmask)
          blur = cv2.GaussianBlur(Rmask,(3,3),0)
          # cv2.imshow('blur',blur)
          canny=cv2.Canny(blur,100,200)
          # cv2.imshow('canny',canny)
          contours,hierarchy  = cv2.findContours(canny, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
          
          for i in range(len(contours)):
               cnt=contours[i]          
               # area = cv2.contourArea(cnt)
               x,y,w,h = cv2.boundingRect(cnt)
               rect_area=w*h  #area size
               aspect_ratio = float(w)/h # ratio = width/height
                  
               # if  (aspect_ratio>=0.2)and(aspect_ratio<=1.0)and(rect_area>=100)and(rect_area<=700): 
               if  (aspect_ratio>=0.95)and(aspect_ratio<=1.05)and(rect_area>=60**2)and(rect_area<=110**2): 
                    cv2.rectangle(img,(x,y),(x+w,y+h),(0,255,0),1)
                    number_plate=copy_img[y+10: y + h-10, x+10: x + w-10]
                    # cv2.imshow('snake',img)    
                    # cv2.waitKey(1)      
                    
                    resize_plate=cv2.resize(number_plate,None,fx=1.8,fy=1.8,interpolation=cv2.INTER_CUBIC+cv2.INTER_LINEAR) 
                    plate_gray=cv2.cvtColor(resize_plate,cv2.COLOR_BGR2HSV)
                    # ret,th_plate = cv2.threshold(plate_gray,150,255,cv2.THRESH_BINARY)
                    img_w = cv2.inRange(plate_gray, self.lower_w, self.upper_w)
                    
                    # cv2.imshow('plate_th',th_plate)

                    kernel = np.ones((3,3),np.uint8)
                    # er_plate = cv2.dilate(img_w,kernel,iterations=1)
                    
                    img_w = cv2.erode(img_w,kernel,iterations=4)
                    # img_w = cv2.dilate(img_w,kernel,iterations=2)
                    img_w = cv2.morphologyEx(img_w, cv2.MORPH_OPEN, kernel)
                    # img_w = cv2.dilate(img_w,kernel,iterations=2)


                    er_invplate = 255-img_w
                    cv2.imshow('er_invplate',er_invplate)
                    cv2.waitKey(1)

                    msg = pytesseract.image_to_string(er_invplate)
                    sign_msg = msg.replace(" ","")
                    # print(sign_msg)
                    # print(sign_msg)
                    # print(sign_msg)
                    return sign_msg

     
     def FindResultA(self, sign_msg):
          A1_list = ['A1','Al','|A1','A1|','A|','A!','Ai','AI','AT','AY','A/']
          A2_list = ['A2','|A2','A2|']
          A3_list = ['A3','|A3','A3|','AS']  

          if self.count == 0:

               if sign_msg in A1_list:
                    self.result_A = 'A1'
                    self.sign = True
                    print(self.result_A)
                    now = rospy.Time.now()
                    self.time_A.append(now.secs)
                    
               elif sign_msg in A2_list:
                    self.result_A = 'A2'
                    self.sign = True
                    print(self.result_A)
                    now = rospy.Time.now()
                    self.time_A.append(now.secs)
                    
               elif sign_msg in A3_list:
                    self.result_A = 'A3'
                    self.sign = True
                    print(self.result_A)
                    now = rospy.Time.now()
                    self.time_A.append(now.secs)

                    
               if self.sign == True:
                    current_time = rospy.Time.now()
                    if (current_time.secs-self.time_A[0]) <= GO_TO_SIGN_SEC: 
                         self.sign_state_pub.publish("read A")
                    elif (current_time.secs-self.time_A[0]) <= GO_TO_SIGN_SEC+WAIT_FOR_DELIVERY_TIME_SEC:
                         self.sign_state_pub.publish("stop")
                    elif (current_time.secs-self.time_A[0]) <= GO_TO_SIGN_SEC+WAIT_FOR_DELIVERY_TIME_SEC + 25:
                         print("pickup complete!!\n")
                         self.sign_state_pub.publish("go")
                    else:
                         self.sign = False
                         self.count = 3
               else:
                    self.sign_state_pub.publish("wait A")
                    print("wait A")
                    

          # if self.count==2:

          #      if sign_msg is self.result_A:
          #           print("Pass A")
          #           self.count = 3

          #      self.sign_pub.publish("go")



     def FindResultB(self, sign_msg):
          B1_list = ['B1','Bl','|B1','B1|','B|','B!','Bi','BI','BT','BY','B/']
          B2_list = ['B2','|B2','B2|']
          B3_list = ['B3','|B3','B3|','BS']          
          
          # if self.count == 1:

          #      if sign_msg in B1_list or sign_msg in B2_list or sign_msg in B3_list:
          #           print("Pass B")
          #           self.count = 2

          #      self.sign_pub.publish("go")
               


          if self.count == 3:

               if sign_msg in B1_list and self.result_A=='A1':
                    self.result_B = 'B1'
                    self.sign = True
                    print(self.result_B)
                    now = rospy.Time.now()
                    self.time_B.append(now.secs)
                    
               elif sign_msg in B2_list and self.result_A=='A2':
                    self.result_B = 'B2'
                    self.sign = True
                    print(self.result_B)
                    now = rospy.Time.now()
                    self.time_B.append(now.secs)
                    
               elif sign_msg in B3_list and self.result_A=='A3':
                    self.result_B = 'B3'
                    self.sign = True
                    print(self.result_B)
                    now = rospy.Time.now()
                    self.time_B.append(now.secs)
                    
               # else : 
               #      self.result = ' '
               #      print(self.result)


               if self.sign == True:
                    current_time = rospy.Time.now()
                    if (current_time.secs-self.time_B[0]) <= GO_TO_SIGN_SEC: 
                              self.sign_state_pub.publish("read B")
                    elif (current_time.secs-self.time_B[0]) <= GO_TO_SIGN_SEC+WAIT_FOR_DELIVERY_TIME_SEC:
                              self.sign_state_pub.publish("stop")
                    else:
                         print("delivery complete!")
                         self.sign_state_pub.publish("go")  
               else:
                    self.sign_state_pub.publish("wait B")
                    print("wait B")


               # current_time = rospy.Time.now()
               # if (current_time.secs-self.time_B[0]) >= 3 and (current_time.secs-self.time_B[0]) <= 8:
               #      self.sign_pub.publish("stop")
               # else:
               #      self.sign_pub.publish("go")




if __name__ == '__main__':
        
     rospy.init_node('sign_detector', anonymous=True)
     rate = rospy.Rate(10)
     SignDetector()

     # while not rospy.is_shutdown():

     #      if sign_detector.img is not None:

     #           roi_img = sign_detector.mask_roi(sign_detector.img)
     #           sign_msg = sign_detector.ExtractNumber(roi_img)
     #           sign_detector.FindResultA(sign_msg)
     #           sign_detector.FindResultB(sign_msg)
     #           rate.sleep()
     rospy.spin() 
     # rate.sleep()



    
    
          

